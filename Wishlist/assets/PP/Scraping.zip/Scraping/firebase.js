const admin = require('firebase-admin');
const serviceAccount = require('./ServiceAccountKey.json');
let { scraper } = require( "./scraper");

// Initialize the app with a service account, granting admin privileges
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});
const db = admin.firestore();

// Set data to database
exports.setProductData = async function (url) {
    let aah = await scraper(url)

    // Placeholder for the uid
    aah.uid = (await admin.auth().getUserByEmail("test@gmail.com")).uid;

    // Insert the object into the database
    await db.collection('wishes').add(aah);
}
