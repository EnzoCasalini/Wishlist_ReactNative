const puppeteer = require('puppeteer');

exports.scraper = async function (url) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto(url);

    let image;
    let title;
    let price;

    try {
        const [el] = await page.$x('//*[@id="landingImage"]');
        const src = await el.getProperty('src');
        image = await src.jsonValue();
    } catch (e) {
        image = "";
    }

    try {
        const [el2] = await page.$x('//*[@id="productTitle"]');
        const text = await el2.getProperty('textContent');
        title = await text.jsonValue();
    } catch (e) {
        title = "No title";
    }

    try {
        const [el3] = await page.$x('//*[@id="corePrice_feature_div"]/div/span/span[1]');
        const text2 = await el3.getProperty('textContent');
        price = await text2.jsonValue();
    } catch (e) {
        price = 'No price';
    }

    return {
        image: image.trim(),
        name: title.trim(),
        price: price.trim()
    };
};