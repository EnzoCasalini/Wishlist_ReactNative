const { setProductData } = require('./firebase')

setProductData("https://www.amazon.fr/Apple-AirPods-Pro-Reconditionn%C3%A9/dp/B08TJ2LGB8/ref=sr_1_8?keywords=airpods&qid=1653138875&sr=8-8");